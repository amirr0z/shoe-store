"use client";
import { useEffect, useState } from "react";
import CrouselCard from "./CrouselCard";

export default function Crousel() {
    const [show, setShow] = useState("0");
    const switcher = (e) => {
        if (show != e.target.getAttribute("data-num")) {
            document
                .getElementById("courselcard" + show)
                .classList.add("hidden");
            setShow(e.target.getAttribute("data-num"));
            document
                .getElementById(
                    "courselcard" + e.target.getAttribute("data-num")
                )
                .classList.remove("hidden");
        }
    };
    useEffect(() => {
        //Implementing the setInterval method
        const interval = setInterval(() => {
            document
                .getElementById("courselcard" + show)
                .classList.add("hidden");
            document
                .getElementById("courselcard" + ((show + 1) % 2))
                .classList.remove("hidden");
            document.getElementById(
                "courselcardradio" + ((show + 1) % 2)
            ).checked = true;
            setShow((show + 1) % 2);
        }, 2000);

        //Clearing the interval
        return () => clearInterval(interval);
    }, [show]);
    return (
        <div className="flex flex-col overflow-hidden items-center justify-center">
            <CrouselCard
                id="0"
                img="slider-6.png"
                title="Walk Into The World Of Comfort"
                content="Step into a world of comfort and style with our exceptional
            shoes, where every stride becomes a journey and every path a
            runway."
            />
            <CrouselCard
                id="1"
                img="slider-5.png"
                title="WalkWonders"
                content="Discover Your Sole Story: Elevate your style and step into the extraordinary with our innovative footwear. Unleash your creativity from the ground up – Welcome to WalkWonders, where every shoe is a canvas for your unique journey."
            />
            <div className="flex flex-row items-center justify-center p-2 [&>*]:cursor-pointer">
                <input
                    name="crouselNum"
                    type="radio"
                    onClick={switcher}
                    data-num="0"
                    className="m-1"
                    id="courselcardradio0"
                    defaultChecked
                />
                <input
                    name="crouselNum"
                    type="radio"
                    onClick={switcher}
                    data-num="1"
                    id="courselcardradio1"
                    className="m-1"
                />
            </div>
        </div>
    );
}
